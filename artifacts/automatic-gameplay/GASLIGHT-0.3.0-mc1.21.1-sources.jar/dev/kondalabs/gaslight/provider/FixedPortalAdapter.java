package dev.kondalabs.gaslight.provider;

import dev.kondalabs.gaslight.NativePortal;
import dev.kondalabs.gaslight.NativePortal.*;
import dev.kondalabs.gaslight.Phase3RecoveryJournal;
import dev.kondalabs.gaslight.StructureEnvelope;
import dev.kondalabs.gaslight.ProtectedChunkRegions;
import java.io.IOException;
import java.nio.file.*;
import java.util.*;
import net.minecraft.class_2338;
import net.minecraft.class_238;
import net.minecraft.class_243;
import net.minecraft.class_3218;
import net.minecraft.class_5218;
import net.minecraft.server.MinecraftServer;
import qouteall.imm_ptl.core.api.PortalAPI;
import qouteall.imm_ptl.core.chunk_loading.ChunkLoader;
import qouteall.imm_ptl.core.portal.Portal;
import qouteall.imm_ptl.core.portal.PortalManipulation;
import qouteall.imm_ptl.core.IPGlobal;

/** Phase A fixed link only. Creation and retirement require no connected observers.
 * Dynamic publication/camera authority is intentionally not claimed or enabled. */
public final class FixedPortalAdapter {
    public static final String TAG="gaslight-phase-a:";
    public static final String MARKER="GASLIGHT_PHASE_A_DISPOSABLE_V1";
    public record Spec(class_3218 source,class_243 origin,class_3218 target,class_243 destination,double width,double height){}
    public record Token(UUID owner,long generation){}
    public record Status(String state,String reason,int portals,int ownedLoaders,int ownedChunks,int intents,long generation){}
    private final MinecraftServer server;
    private final Phase3RecoveryJournal.Store journal;
    private final Set<UUID> authorized=new HashSet<>();
    private final List<Portal> portals=new ArrayList<>();
    private final List<ChunkLoader> loaders=new ArrayList<>();
    private String state="DISABLED",reason="disposable marker absent";
    private Token token;private long generation;private boolean hadViewer;
    private Spec spec;
    private SavedDestinationPreparation preparation;
    private Spec preparingSpec;
    private final int previousRadius,previousLayers,previousRenderLimit;

    FixedPortalAdapter(MinecraftServer server){
        this.server=server;
        previousRadius=IPGlobal.indirectLoadingRadiusCap;previousLayers=IPGlobal.maxPortalLayer;previousRenderLimit=IPGlobal.portalRenderLimit;
        Path root=server.method_27050(class_5218.field_24188);
        boolean permitted=false;
        try { Path marker=root.resolve(".gaslight-phase-a-disposable");permitted=Files.isRegularFile(marker,LinkOption.NOFOLLOW_LINKS)&&Files.size(marker)<=128&&Files.readString(marker).trim().equals(MARKER); }
        catch(IOException|RuntimeException ignored) { /* Absent or unreadable authorization keeps all effects disabled. */ }
        // New recovery profile never migrates or ignores legacy unresolved evidence.
        if(permitted&&Boolean.getBoolean("gaslight.sqlite")&&Files.exists(root.resolve("data/gaslight-phase-a"))) {
            journal=null;state="QUARANTINED";reason="legacy journal directory retained; SQLite migration refused";
        } else journal=!permitted?null:Boolean.getBoolean("gaslight.sqlite")?
            new SqliteIntentStore(root.resolve("data/gaslight-recovery/intents.sqlite")):
            new Phase3RecoveryJournal.FileStore(root.resolve("data/gaslight-phase-a/intents.bin"));
        if(journal!=null){ state=journal.blockedOnOpen()?"QUARANTINED":"IDLE";reason=journal.diagnostic();IPGlobal.indirectLoadingRadiusCap=2;IPGlobal.maxPortalLayer=2;IPGlobal.portalRenderLimit=8; }
    }
    public static boolean owned(Portal p){return p.portalTag!=null&&p.portalTag.startsWith(TAG);}
    boolean permits(Portal p){return authorized.contains(p.method_5667()) && (state.equals("STAGING")||state.equals("ACTIVE"));}
    private void thread(){if(!server.method_18854())throw new IllegalStateException("server thread required");}
    private boolean refuse(String why){reason=why;GaslightProvider.LOG.info("GASLIGHT_FIXED_REFUSED {}",why);return false;}
    public Status status(){thread();return new Status(state,reason,portals.size(),loaders.size(),loaders.stream().mapToInt(ChunkLoader::getChunkNum).sum(),journal==null?0:journal.outstanding(),generation);}
    public Token token(){thread();return token;}
    public boolean acquireSaved(Spec requested){
        thread();
        if(journal==null||journal.blockedOnOpen()||preparation!=null||!state.equals("IDLE")||!server.method_3760().method_14571().isEmpty())return refuse("saved acquisition requires clean observer-free idle service");
        try{preparation=new SavedDestinationPreparation(server,requested);preparingSpec=requested;state="PREPARING";reason="saved-only bounded acquisition";return true;}
        catch(RuntimeException bad){return refuse(bad.toString());}
    }
    public String preparationStatus(){thread();return preparation==null?"none":preparation.stats().toString();}
    public boolean cancelPreparation(UUID owner){
        thread();if(preparation==null||!preparation.owner.equals(owner))return refuse("stale preparation cancellation");
        preparation.close();preparation=null;preparingSpec=null;state="IDLE";reason="preparation cancelled; no publication";return true;
    }
    public UUID preparationOwner(){thread();return preparation==null?null:preparation.owner;}
    void recoverGuardedOwnership(){
        thread();
        // ENTITY_LOAD permanently rejects every portal outside this session's
        // authorized set. Persisted stale entities can never regain authority.
        if(journal instanceof SqliteIntentStore store&&preparation==null&&authorized.isEmpty()&&portals.isEmpty()&&loaders.isEmpty()&&server.method_3760().method_14571().isEmpty()){
            if(store.reconcileWithLoadVeto()){state="IDLE";reason=store.diagnostic();}
            else {state="QUARANTINED";reason=store.diagnostic();}
            GaslightProvider.LOG.info("GASLIGHT_GUARDED_RECOVERY {}",status());
        }
    }
    public boolean prepare(Spec s){
        thread();
        if(journal==null||journal.blockedOnOpen()||!state.equals("IDLE"))return refuse("disabled, outstanding recovery or active generation");
        if(!server.method_3760().method_14571().isEmpty())return refuse("publication requires an observer-free server");
        try {
            Objects.requireNonNull(s);Objects.requireNonNull(s.source);Objects.requireNonNull(s.target);
            if(s.source.method_8503()!=server||s.target.method_8503()!=server)throw new IllegalArgumentException("foreign world");
            Surface a=surface(s.origin,s.width,s.height),b=surface(s.destination,s.width,s.height);
            if(s.width>16||s.height>16||s.width<2||s.height<3)throw new IllegalArgumentException("fixed prototype size budget");
            audit(s.source,a);audit(s.target,b);
            for(var side:List.of(Map.entry(s.source,s.origin),Map.entry(s.target,s.destination)))if(side.getKey().method_8335(null,box(side.getValue(),s.width,s.height).method_1014(1)).stream().anyMatch(e->!e.method_31481()))throw new IllegalArgumentException("occupied portal footprint");
            token=new Token(UUID.randomUUID(),++generation);spec=s;
            // NativePortal geometry is an intent carrier; provider API owns the actual rigid transform.
            if(!journal.begin(List.of(new Passage(a,b,token.owner,token.generation)))){state="QUARANTINED";return refuse("durable intent refused: "+journal.diagnostic());}
            state="STAGING";
            addLoader(s.source,s.origin);addLoader(s.target,s.destination);
            Portal forward=EphemeralPortal.TYPE.method_5883(s.source);
            if(forward==null)throw new IllegalStateException("provider entity creation failed");
            forward.setOriginPos(s.origin);forward.setOrientationAndSize(new class_243(1,0,0),new class_243(0,1,0),s.width,s.height);
            forward.setDestinationDimension(s.target.method_27983());forward.setDestination(s.destination);
            forward.setScaleTransformation(1);forward.setRotation(null);
            var reverse=PortalManipulation.createReversePortal(forward,EphemeralPortal.TYPE);
            for(Portal p:List.of(forward,PortalManipulation.createFlippedPortal(forward,EphemeralPortal.TYPE),reverse,PortalManipulation.createFlippedPortal(reverse,EphemeralPortal.TYPE))){
                if(p.method_31746()||p.method_5864()!=EphemeralPortal.TYPE)throw new IllegalStateException("ephemeral ownership contract");
                p.portalTag=TAG+token.owner+":"+token.generation;
                authorized.add(p.method_5667());portals.add(p);
                if(!((class_3218)p.method_37908()).method_8649(p))throw new IllegalStateException("provider spawn refused");
            }
            state="ACTIVE";reason="fixed rigid link ready; automatic replacement disabled";hadViewer=false;
            GaslightProvider.LOG.info("GASLIGHT_FIXED_READY {}",status());return true;
        }catch(RuntimeException failure){
            reason=failure.toString();
            if(state.equals("STAGING")){rollback();state="QUARANTINED";} // Keep uncertain intent for recovery.
            return refuse(reason);
        }
    }
    private static Surface surface(class_243 v,double w,double h){Objects.requireNonNull(v);return new Surface(new V(v.field_1352,v.field_1351,v.field_1350),new V(1,0,0),w,h);}
    private static class_238 box(class_243 p,double w,double h){return new class_238(p.field_1352-w/2,p.field_1351-h/2,p.field_1350-.1,p.field_1352+w/2,p.field_1351+h/2,p.field_1350+.1);}
    private static void audit(class_3218 world,Surface s){
        var policy=ProtectedChunkRegions.load(world.method_8503().method_27050(class_5218.field_24188).resolve("gaslight-protected-chunks.csv"));
        if(!policy.valid())throw new IllegalArgumentException(policy.reason());
        if(s.centre().y()-s.height()/2<world.method_31607()||s.centre().y()+s.height()/2>world.method_31600())throw new IllegalArgumentException("build height");
        var result=StructureEnvelope.audit(s,1,25,(x,z)->{
            var chunk=world.method_14178().method_21730(x,z);
            if(chunk==null)return StructureEnvelope.Result.UNKNOWN;
            if(policy.protectedAt(x,z))return StructureEnvelope.Result.USER_PROTECTED;
            if(!world.method_8621().method_11952(new class_2338(x*16,(int)s.centre().y(),z*16)))return StructureEnvelope.Result.UNKNOWN;
            if(chunk.method_12016().values().stream().anyMatch(start->start!=null&&start.method_16657())||chunk.method_12179().values().stream().anyMatch(ref->!ref.isEmpty()))return StructureEnvelope.Result.STRUCTURE;
            return StructureEnvelope.Result.SAFE;
        });
        if(!result.accepted())throw new IllegalArgumentException(result.reason());
        // Provider lease touches 5x5; unknown/structured lease dependencies are vetoes too.
        int cx=Math.floorDiv((int)Math.floor(s.centre().x()),16),cz=Math.floorDiv((int)Math.floor(s.centre().z()),16);
        for(int x=cx-2;x<=cx+2;x++)for(int z=cz-2;z<=cz+2;z++){
            var chunk=world.method_14178().method_21730(x,z);
            if(chunk==null||policy.protectedAt(x,z)||!world.method_8621().method_11952(new class_2338(x*16,(int)s.centre().y(),z*16))||chunk.method_12016().values().stream().anyMatch(start->start!=null&&start.method_16657())||chunk.method_12179().values().stream().anyMatch(ref->!ref.isEmpty()))throw new IllegalArgumentException("uncertified lease footprint");
        }
    }
    private void addLoader(class_3218 world,class_243 p){
        var loader=new ChunkLoader(world.method_27983(),Math.floorDiv((int)Math.floor(p.field_1352),16),Math.floorDiv((int)Math.floor(p.field_1350),16),2);
        PortalAPI.addGlobalChunkLoader(server,loader);loaders.add(loader);
    }
    private void rollback(){
        for(Portal p:portals){p.setTeleportable(false);p.setIsVisible(false);p.method_31472();}portals.clear();authorized.clear();
        for(ChunkLoader l:loaders)PortalAPI.removeGlobalChunkLoader(server,l);loaders.clear();
    }
    public boolean retire(Token requested){
        thread();if(token!=requested||!state.equals("ACTIVE"))return refuse("stale retirement token");
        if(!server.method_3760().method_14571().isEmpty())return refuse("retirement requires no observers");
        for(Portal p:portals)if(!p.method_37908().method_8333(p,p.method_5829().method_1014(1),e->!(e instanceof Portal)).isEmpty())return refuse("crossing occupancy");
        rollback();
        if(journal instanceof SqliteIntentStore){
            if(!authorized.isEmpty()||!portals.isEmpty()||!loaders.isEmpty()||!journal.settle(token.owner,token.generation)){
                state="QUARANTINED";return refuse("guarded retirement failed: "+journal.diagnostic());
            }
            state="IDLE";reason=journal.diagnostic();spec=null;hadViewer=false;
            GaslightProvider.LOG.info("GASLIGHT_FIXED_RETIRED {}",status());return true;
        }
        // Vanilla save completion is not an authenticated durable entity-removal receipt.
        // Keep the intent until Phase C supplies crash reconciliation; never silently settle it.
        if(!server.method_39218(false,true,true)){state="QUARANTINED";return refuse("retirement save failure; unresolved intent retained");}
        state="RETIRED_PENDING_RECOVERY";reason="closed; durable intent retained for crash reconciliation";spec=null;hadViewer=false;
        GaslightProvider.LOG.info("GASLIGHT_FIXED_RETIRED {}",status());return true;
    }
    void tick(){thread();
        if(preparation!=null){
            if(!server.method_3760().method_14571().isEmpty()){cancelPreparation(preparation.owner);return;}
            preparation.tick();
            if(preparation.state()==SavedDestinationPreparation.State.READY){
                GaslightProvider.LOG.info("GASLIGHT_SAVED_READY {}",preparation.stats());
                var work=preparation;var requested=preparingSpec;preparation=null;preparingSpec=null;state="IDLE";
                try{prepare(requested);}finally{work.close();}
            }else if(preparation.state()==SavedDestinationPreparation.State.FAILED){
                reason=preparation.stats().toString();GaslightProvider.LOG.warn("GASLIGHT_SAVED_FAILED {}",reason);preparation.close();preparation=null;preparingSpec=null;state="IDLE";
            }
        }
        if(state.equals("ACTIVE")){if(!server.method_3760().method_14571().isEmpty())hadViewer=true;else if(hadViewer)retire(token);}
    }
    void shutdown(){thread();if(preparation!=null)cancelPreparation(preparation.owner);if(state.equals("ACTIVE")&&!retire(token)){rollback();state="QUARANTINED";reason="shutdown retains unresolved intent";}if(journal!=null){IPGlobal.indirectLoadingRadiusCap=previousRadius;IPGlobal.maxPortalLayer=previousLayers;IPGlobal.portalRenderLimit=previousRenderLimit;}if(journal instanceof SqliteIntentStore store)store.close();}
}
