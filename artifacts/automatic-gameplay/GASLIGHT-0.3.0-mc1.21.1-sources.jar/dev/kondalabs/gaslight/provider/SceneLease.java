package dev.kondalabs.gaslight.provider;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1923;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3230;
import net.minecraft.class_9259;
import net.minecraft.class_9768;
import net.minecraft.server.level.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.chunk.status.*;

/** Native generation is allowed only in GASLIGHT's private dimension. The native
 * dependency footprint is admitted before a ticket; requests never mean air. */
final class SceneLease implements AutoCloseable {
    private static final class_3230<UUID> TICKET=class_3230.method_14291("gaslight_scene",Comparator.comparing(UUID::toString));
    private final class_3218 world;
    private final UUID owner=UUID.randomUUID();
    private final List<class_1923> targets=new ArrayList<>();
    private final Set<class_1923> tickets=new HashSet<>(),ready=new HashSet<>();
    private final Map<class_1923,CompletableFuture<class_9259<class_2791>>> pending=new HashMap<>();
    private final long deadline=System.nanoTime()+45_000_000_000L;
    private int cursor;
    final int dependencies;
    private boolean closed;
    private final boolean requireUnvisited;
    private int readCursor,readDone;
    private final Map<class_1923,CompletableFuture<Optional<net.minecraft.class_2487>>> reads=new HashMap<>();
    SceneLease(class_3218 world,int cx,int cz,int radius) {
        this(world,cx,cz,radius,false);
    }
    SceneLease(class_3218 world,int cx,int cz,int radius,boolean requireUnvisited) {
        if(!world.method_27983().equals(AutomaticPortalService.WORLD)||radius<1||radius>4)throw new IllegalArgumentException("generation/world budget");
        this.world=world;
        this.requireUnvisited=requireUnvisited;
        int halo=class_9768.field_51900.method_60518(class_2806.field_12803).comp_2805().method_60517();
        dependencies=(2*(radius+halo)+1)*(2*(radius+halo)+1);
        if(halo>12||dependencies>1024)throw new IllegalArgumentException("native dependency budget");
        for(int x=cx-radius;x<=cx+radius;x++)for(int z=cz-radius;z<=cz+radius;z++) {
            if(!world.method_8621().method_11952(new net.minecraft.class_2338(x*16,64,z*16)))throw new IllegalArgumentException("world border");
            targets.add(new class_1923(x,z));
        }
    }
    boolean tick() {
        if(closed||System.nanoTime()>deadline)throw new IllegalStateException("preparation closed/timed out");
        if(requireUnvisited&&readDone<targets.size()){
            for(var it=reads.entrySet().iterator();it.hasNext();){var e=it.next();if(!e.getValue().isDone())continue;var saved=e.getValue().join();it.remove();
                if(saved.isPresent()){
                    String status=saved.get().method_10558("Status");
                    if(status.isEmpty()||status.equals("minecraft:full")||status.equals("full"))throw new IllegalStateException("private reservation already FULL or unreadable: "+e.getKey());
                }
                readDone++;
            }
            while(reads.size()<2&&readCursor<targets.size()){
                var pos=targets.get(readCursor++);
                if(world.method_14178().method_21730(pos.field_9181,pos.field_9180)!=null)throw new IllegalStateException("private reservation already loaded/visited: "+pos);
                reads.put(pos,world.method_14178().field_17254.method_23696(pos));
            }
            if(readDone<targets.size())return false;
        }
        for(var it=pending.entrySet().iterator();it.hasNext();) {
            var e=it.next();if(!e.getValue().isDone())continue;
            var result=e.getValue().join();it.remove();
            if(result.method_57122()&&result.method_57130(null) instanceof class_2818)ready.add(e.getKey());
        }
        while(pending.size()<2&&cursor<targets.size()) {
            var p=targets.get(cursor++);if(ready.contains(p))continue;
            if(tickets.add(p))world.method_14178().method_17297(TICKET,p,0,owner);
            pending.put(p,world.method_14178().method_17299(p.field_9181,p.field_9180,class_2806.field_12803,true));
        }
        if(cursor==targets.size()&&pending.isEmpty()&&ready.size()!=targets.size())cursor=0;
        return ready.size()==targets.size()&&!world.method_14178().method_17293().method_15518();
    }
    int tickets(){return tickets.size();}
    @Override public void close() {
        if(closed)return;closed=true;
        for(var p:tickets)world.method_14178().method_17300(TICKET,p,0,owner);
        tickets.clear();pending.clear();reads.clear();
    }
}
