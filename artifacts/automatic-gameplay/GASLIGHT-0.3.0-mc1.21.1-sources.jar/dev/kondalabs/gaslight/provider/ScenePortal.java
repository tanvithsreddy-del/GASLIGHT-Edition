package dev.kondalabs.gaslight.provider;

import net.minecraft.class_1297;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.world.entity.*;
import qouteall.imm_ptl.core.portal.Portal;

/** Render selection and physical publication have separate fences. */
public final class ScenePortal extends Portal {
    public static final class_1299<ScenePortal> TYPE=class_2378.method_10230(class_7923.field_41177,class_2960.method_60655("gaslight_provider","scene_portal"),class_1299.class_1300.<ScenePortal>method_5903(ScenePortal::new,class_1311.field_17715).method_17687(0,0).method_19947().method_5904().method_5901().method_27299(8).method_27300(20).method_5905("gaslight_provider:scene_portal"));
    public ScenePortal(class_1299<?> type,class_1937 world){super(type,world);}
    public static void initialize(){}
    @Override public boolean method_31746(){return false;}
    @Override public boolean isVisible(){return method_37908().field_9236?SceneVisibility.visible(portalTag):serverActive();}
    private boolean serverActive(){var service=GaslightProvider.automatic(method_37908().method_8503());return service!=null&&service.active(portalTag);}
    @Override public boolean isTeleportable(){return (method_37908().field_9236?SceneVisibility.interactive(portalTag):serverActive())&&super.isTeleportable();}
    @Override public boolean isInteractable(){return (method_37908().field_9236?SceneVisibility.interactive(portalTag):serverActive())&&super.isInteractable();}
    @Override public boolean canTeleportEntity(class_1297 entity){
        return (method_37908().field_9236?SceneVisibility.interactive(portalTag):serverActive())&&super.canTeleportEntity(entity);
    }
}
