package dev.kondalabs.gaslight.provider.mixin;
import dev.kondalabs.gaslight.provider.AutomaticClient;
import net.minecraft.class_1269;
import net.minecraft.class_636;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.injection.*;
import org.spongepowered.asm.mixin.injection.callback.*;
@Mixin(class_636.class)
public class SelectionInteractionFence {
    @Inject(method={"destroyBlock","startDestroyBlock","continueDestroyBlock"},at=@At("HEAD"),cancellable=true)
    private void gaslight$block(CallbackInfoReturnable<Boolean> cir){if(AutomaticClient.selecting())cir.setReturnValue(false);}
    @Inject(method={"useItemOn","useItem","interact","interactAt"},at=@At("HEAD"),cancellable=true)
    private void gaslight$interact(CallbackInfoReturnable<class_1269> cir){if(AutomaticClient.selecting())cir.setReturnValue(class_1269.field_5814);}
    @Inject(method="attack",at=@At("HEAD"),cancellable=true)
    private void gaslight$attack(CallbackInfo ci){if(AutomaticClient.selecting())ci.cancel();}
}
