package dev.kondalabs.gaslight.provider.mixin;
import net.minecraft.class_2535;
import net.minecraft.class_8609;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.gen.Accessor;
@Mixin(class_8609.class)
public interface SceneConnectionAccessor {
    @Accessor("connection") class_2535 gaslight$connection();
}
