package dev.kondalabs.gaslight.provider;

import java.util.UUID;
import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.class_243;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;

final class SceneProtocol {
    private static final java.util.Map<UUID,Caps> CAPABILITIES=new java.util.concurrent.ConcurrentHashMap<>();
    static boolean supported(net.minecraft.class_3222 player){var cap=CAPABILITIES.get(player.method_5667());return cap!=null&&cap.protocol()==1&&cap.vanillaRenderer()&&cap.renderDistance()>=2&&cap.renderDistance()<=4;}
    private static <T extends class_8710> class_8710.class_9154<T> type(String name) {
        return new class_8710.class_9154<>(class_2960.method_60655("gaslight_provider",name));
    }
    static void vector(class_9129 b,class_243 v){b.method_52940(v.field_1352);b.method_52940(v.field_1351);b.method_52940(v.field_1350);}
    static class_243 vector(class_9129 b){return new class_243(b.readDouble(),b.readDouble(),b.readDouble());}
    record Caps(int protocol,boolean vanillaRenderer,int renderDistance) implements class_8710 {
        static final class_9154<Caps> TYPE=SceneProtocol.type("scene_capabilities");
        static final class_9139<class_9129,Caps> CODEC=class_9139.method_56437((b,p)->{b.method_53002(p.protocol);b.method_52964(p.vanillaRenderer);b.method_53002(p.renderDistance);},b->new Caps(b.readInt(),b.readBoolean(),b.readInt()));
        Caps{if(protocol<0||protocol>16||renderDistance<0||renderDistance>128)throw new IllegalArgumentException("capability bounds");}
        @Override public class_9154<Caps> method_56479(){return TYPE;}
    }
    record Offer(UUID session,long generation,class_243 origin,class_243 destination,boolean xPlane,int sign,int minY,int maxY,UUID first,UUID second,class_243 previous,class_243 previousDestination,boolean previousXPlane,int previousSign,String seamDigest) implements class_8710 {
        static final class_9154<Offer> TYPE=SceneProtocol.type("scene_offer");
        static final class_9139<class_9129,Offer> CODEC=class_9139.method_56437((b,p)->{
            b.method_10797(p.session);b.method_52974(p.generation);vector(b,p.origin);vector(b,p.destination);b.method_52964(p.xPlane);b.method_53002(p.sign);b.method_53002(p.minY);b.method_53002(p.maxY);b.method_10797(p.first);b.method_10797(p.second);b.method_52964(p.previous!=null);if(p.previous!=null){vector(b,p.previous);vector(b,p.previousDestination);}b.method_52964(p.previousXPlane);b.method_53002(p.previousSign);b.method_10788(p.seamDigest,64);
        },b->{UUID s=b.method_10790();long g=b.readLong();class_243 a=vector(b),d=vector(b);boolean x=b.readBoolean();int sign=b.readInt(),lo=b.readInt(),hi=b.readInt();UUID p=b.method_10790(),q=b.method_10790();boolean had=b.readBoolean();class_243 old=had?vector(b):null,oldDest=had?vector(b):null;return new Offer(s,g,a,d,x,sign,lo,hi,p,q,old,oldDest,b.readBoolean(),b.readInt(),b.method_10800(64));});
        Offer {
            if(session==null||generation<1||first==null||second==null||Math.abs(sign)!=1||Math.abs(previousSign)!=1||minY< -2048||maxY>2048||maxY<=minY||maxY-minY>512||seamDigest==null||!seamDigest.matches("[0-9a-f]{64}"))throw new IllegalArgumentException("offer fence");
            for(class_243 p:previous==null?java.util.List.of(origin,destination):java.util.List.of(origin,destination,previous,previousDestination))
                if(p==null||!Double.isFinite(p.field_1352)||!Double.isFinite(p.field_1351)||!Double.isFinite(p.field_1350)||Math.abs(p.field_1352)>29_000_000||Math.abs(p.field_1350)>29_000_000||Math.abs(p.field_1351)>2048)throw new IllegalArgumentException("offer coordinate");
        }
        @Override public class_9154<Offer> method_56479(){return TYPE;}
        boolean hidden(FrameClip clip) {
            return halfHidden(clip,origin,xPlane,sign) && (previous==null||(planeHidden(clip,previous,previousXPlane)&&planeHidden(clip,previousDestination,previousXPlane)));
        }
        private boolean planeHidden(FrameClip clip,class_243 p,boolean x){return clip.excludes(p.field_1352-(x?.01:32),minY,p.field_1350-(x?32:.01),p.field_1352+(x?.01:32),maxY,p.field_1350+(x?32:.01));}
        private boolean halfHidden(FrameClip clip,class_243 p,boolean x,int direction){
            double lo=-30_000_000,hi=30_000_000;
            return x?clip.excludes(direction>0?lo:p.field_1352,minY,lo,direction>0?p.field_1352:hi,maxY,hi):clip.excludes(lo,minY,direction>0?lo:p.field_1350,hi,maxY,direction>0?p.field_1350:hi);
        }
    }
    record Ready(UUID session,long generation,int meshes,int cells,String seamDigest) implements class_8710 {
        static final class_9154<Ready> TYPE=SceneProtocol.type("scene_ready");
        static final class_9139<class_9129,Ready> CODEC=class_9139.method_56437((b,p)->{b.method_10797(p.session);b.method_52974(p.generation);b.method_53002(p.meshes);b.method_53002(p.cells);b.method_10788(p.seamDigest,64);},b->new Ready(b.method_10790(),b.readLong(),b.readInt(),b.readInt(),b.method_10800(64)));
        Ready{if(session==null||generation<1||meshes<1||meshes>2048||cells<1||cells>65536||seamDigest==null||!seamDigest.matches("[0-9a-f]{64}"))throw new IllegalArgumentException("readiness bounds");}
        @Override public class_9154<Ready> method_56479(){return TYPE;}
    }
    record Selection(UUID session,long generation,long frame,FrameClip clip) implements class_8710 {
        static final class_9154<Selection> TYPE=SceneProtocol.type("scene_selection");
        static final class_9139<class_9129,Selection> CODEC=class_9139.method_56437((b,p)->{b.method_10797(p.session);b.method_52974(p.generation);b.method_52974(p.frame);b.method_52940(p.clip.x());b.method_52940(p.clip.y());b.method_52940(p.clip.z());for(float f:p.clip.matrix())b.method_52941(f);},b->{UUID s=b.method_10790();long g=b.readLong(),f=b.readLong();double x=b.readDouble(),y=b.readDouble(),z=b.readDouble();float[] m=new float[16];for(int i=0;i<16;i++)m[i]=b.readFloat();return new Selection(s,g,f,new FrameClip(x,y,z,m));});
        @Override public class_9154<Selection> method_56479(){return TYPE;}
    }
    record Armed(UUID session,long generation) implements class_8710 {
        static final class_9154<Armed> TYPE=SceneProtocol.type("scene_armed");
        static final class_9139<class_9129,Armed> CODEC=class_9139.method_56437((b,p)->{b.method_10797(p.session);b.method_52974(p.generation);},b->new Armed(b.method_10790(),b.readLong()));
        @Override public class_9154<Armed> method_56479(){return TYPE;}
    }
    record Cancel(UUID session,long generation) implements class_8710 {
        static final class_9154<Cancel> TYPE=SceneProtocol.type("scene_cancel");
        static final class_9139<class_9129,Cancel> CODEC=class_9139.method_56437((b,p)->{b.method_10797(p.session);b.method_52974(p.generation);},b->new Cancel(b.method_10790(),b.readLong()));
        @Override public class_9154<Cancel> method_56479(){return TYPE;}
    }
    record Withdraw(UUID session,long generation) implements class_8710 {
        static final class_9154<Withdraw> TYPE=SceneProtocol.type("scene_withdraw");
        static final class_9139<class_9129,Withdraw> CODEC=class_9139.method_56437((b,p)->{b.method_10797(p.session);b.method_52974(p.generation);},b->new Withdraw(b.method_10790(),b.readLong()));
        @Override public class_9154<Withdraw> method_56479(){return TYPE;}
    }
    record Ack(UUID session,long generation,long frame,boolean accepted) implements class_8710 {
        static final class_9154<Ack> TYPE=SceneProtocol.type("scene_ack");
        static final class_9139<class_9129,Ack> CODEC=class_9139.method_56437((b,p)->{b.method_10797(p.session);b.method_52974(p.generation);b.method_52974(p.frame);b.method_52964(p.accepted);},b->new Ack(b.method_10790(),b.readLong(),b.readLong(),b.readBoolean()));
        @Override public class_9154<Ack> method_56479(){return TYPE;}
    }
    static void initialize(){
        PayloadTypeRegistry.playS2C().register(Offer.TYPE,Offer.CODEC);PayloadTypeRegistry.playS2C().register(Ack.TYPE,Ack.CODEC);PayloadTypeRegistry.playC2S().register(Selection.TYPE,Selection.CODEC);PayloadTypeRegistry.playC2S().register(Ready.TYPE,Ready.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(Ready.TYPE,(p,c)->{var s=GaslightProvider.automatic(c.server());if(s!=null)s.clientReady(c.player(),p);});
        PayloadTypeRegistry.playC2S().register(Cancel.TYPE,Cancel.CODEC);PayloadTypeRegistry.playS2C().register(Withdraw.TYPE,Withdraw.CODEC);
        PayloadTypeRegistry.playS2C().register(Armed.TYPE,Armed.CODEC);
        PayloadTypeRegistry.playC2S().register(Caps.TYPE,Caps.CODEC);
        ServerPlayNetworking.registerGlobalReceiver(Caps.TYPE,(p,c)->{if(c.server().method_3760().method_14574()<=4)CAPABILITIES.put(c.player().method_5667(),p);});
        ServerPlayNetworking.registerGlobalReceiver(Cancel.TYPE,(p,c)->{var s=GaslightProvider.automatic(c.server());if(s!=null)s.cancel(c.player(),p);});
        ServerPlayNetworking.registerGlobalReceiver(Selection.TYPE,(p,c)->{var s=GaslightProvider.automatic(c.server());if(s!=null)s.select(c.player(),p);});
        ServerPlayConnectionEvents.DISCONNECT.register((h,s)->s.execute(()->{CAPABILITIES.remove(h.field_14140.method_5667());var a=GaslightProvider.automatic(s);if(a!=null)a.disconnected(h.field_14140);}));
    }
}
