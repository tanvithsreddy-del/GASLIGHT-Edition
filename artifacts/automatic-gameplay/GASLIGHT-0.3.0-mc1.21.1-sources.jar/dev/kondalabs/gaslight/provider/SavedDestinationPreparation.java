package dev.kondalabs.gaslight.provider;

import java.util.*;
import java.util.concurrent.CompletableFuture;
import net.minecraft.class_1923;
import net.minecraft.class_2487;
import net.minecraft.class_2519;
import net.minecraft.class_2520;
import net.minecraft.class_2791;
import net.minecraft.class_2806;
import net.minecraft.class_2818;
import net.minecraft.class_3218;
import net.minecraft.class_3230;
import net.minecraft.class_6841;
import net.minecraft.class_6843;
import net.minecraft.class_9259;
import net.minecraft.class_9768;
import net.minecraft.nbt.*;
import net.minecraft.nbt.visitors.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import net.minecraft.world.level.chunk.*;
import net.minecraft.world.level.chunk.status.*;

/** Saved-data-only acquisition. No ticket is issued until every native loading
 * dependency has sufficient persisted status. Never interprets absence as air.
 * Futures are observed on the server thread; cancellation releases only our tickets. */
final class SavedDestinationPreparation implements AutoCloseable {
    enum State {SCANNING,LOADING,READY,FAILED,CANCELLED}
    record Key(class_3218 world,int x,int z){}
    record Stats(State state,int checked,int footprint,int tickets,int pending,double elapsedMs,String reason){}
    private static final class_3230<UUID> TICKET=class_3230.method_14291("gaslight_saved_prepare",Comparator.comparing(UUID::toString));
    private final MinecraftServer server;
    final UUID owner=UUID.randomUUID();
    private final long start=System.nanoTime(),deadline=start+30_000_000_000L;
    private final LinkedHashMap<Key,class_2806> required=new LinkedHashMap<>();
    private final List<Key> targets=new ArrayList<>();
    private final Map<Key,CompletableFuture<Boolean>> scans=new LinkedHashMap<>();
    private final Map<Key,CompletableFuture<class_9259<class_2791>>> loads=new LinkedHashMap<>();
    private final Set<Key> tickets=new LinkedHashSet<>(),loaded=new HashSet<>();
    private int cursor,checked,loadCursor;
    private State state=State.SCANNING;private String reason="checking persisted native dependency statuses";
    SavedDestinationPreparation(MinecraftServer server,FixedPortalAdapter.Spec spec){
        this.server=server;
        int halo=class_9768.field_51901.method_60518(class_2806.field_12803).comp_2805().method_60517();
        if(halo<0||halo>3)throw new IllegalArgumentException("unsupported native loading footprint");
        for(var side:List.of(Map.entry(spec.source(),spec.origin()),Map.entry(spec.target(),spec.destination()))){
            if(side.getKey().method_8503()!=server||!Double.isFinite(side.getValue().field_1352)||!Double.isFinite(side.getValue().field_1350)||Math.abs(side.getValue().field_1352)>29_000_000||Math.abs(side.getValue().field_1350)>29_000_000)throw new IllegalArgumentException("world/coordinate fence");
            int cx=Math.floorDiv((int)Math.floor(side.getValue().field_1352),16),cz=Math.floorDiv((int)Math.floor(side.getValue().field_1350),16);
            for(int x=cx-2;x<=cx+2;x++)for(int z=cz-2;z<=cz+2;z++){
                Key target=new Key(side.getKey(),x,z);if(!targets.contains(target))targets.add(target);
                var dependencies=class_9768.field_51901.method_60518(class_2806.field_12803).comp_2805();
                for(int dx=-halo;dx<=halo;dx++)for(int dz=-halo;dz<=halo;dz++){
                    var key=new Key(side.getKey(),x+dx,z+dz);int distance=Math.max(Math.abs(dx),Math.abs(dz));
                    class_2806 status=dependencies.method_60514(distance);
                    required.merge(key,status,(a,b)->a.method_12165(b)?a:b);
                }
            }
        }
        if(targets.size()>50||required.size()>98)throw new IllegalArgumentException("native acquisition footprint budget");
    }
    private void thread(){if(!server.method_18854())throw new IllegalStateException("server thread required");}
    Stats stats(){thread();return new Stats(state,checked,required.size(),tickets.size(),scans.size()+loads.size(),(System.nanoTime()-start)/1e6,reason);}
    State state(){return state;}
    void tick(){
        thread();if(state==State.FAILED||state==State.CANCELLED||state==State.READY)return;
        if(System.nanoTime()>deadline){fail("preparation deadline");return;}
        try{
            if(state==State.SCANNING){
                for(var it=scans.entrySet().iterator();it.hasNext();){var e=it.next();if(e.getValue().isDone()){
                    if(!e.getValue().join()){fail("saved destination or dependency unavailable: "+e.getKey());return;}
                    checked++;it.remove();
                }}
                var keys=new ArrayList<>(required.keySet());
                while(scans.size()<2&&cursor<keys.size()){
                    Key key=keys.get(cursor++);class_2806 minimum=required.get(key);
                    var resident=key.world.method_14178().method_21730(key.x,key.z);
                    if(resident!=null&&resident.method_12009().method_12165(minimum)){checked++;continue;}
                    class_6841 collector=new class_6841(new class_6843(class_2519.field_21045,"Status"));
                    scans.put(key,key.world.method_14178().method_39777().method_39795(new class_1923(key.x,key.z),collector).thenApply(ignored->{
                        if(!(collector.method_39887() instanceof class_2487 tag)||!tag.method_10573("Status",class_2520.field_33258))return false;
                        class_2806 actual=class_2806.method_12168(tag.method_10558("Status"));return actual!=null&&actual.method_12165(minimum);
                    }));
                }
                if(checked==required.size()){state=State.LOADING;reason="saved dependencies certified; bounded ticket acquisition";}
            }
            if(state==State.LOADING){
                for(var it=loads.entrySet().iterator();it.hasNext();){var e=it.next();if(!e.getValue().isDone())continue;
                    var result=e.getValue().join();it.remove();
                    if(result.method_57122()&&result.method_57130(null) instanceof class_2818)loaded.add(e.getKey());
                    // A false-create request may precede the distance-manager update.
                    // Keep the owned ticket, retry later, and retain the original deadline.
                }
                while(loads.size()<2&&loadCursor<targets.size()){
                    Key key=targets.get(loadCursor++);
                    if(loaded.contains(key))continue;
                    if(tickets.add(key))key.world.method_14178().method_17297(TICKET,new class_1923(key.x,key.z),0,owner);
                    loads.put(key,key.world.method_14178().method_17299(key.x,key.z,class_2806.field_12803,false));
                }
                if(loadCursor==targets.size()&&loads.isEmpty()){
                    if(loaded.size()==targets.size()){state=State.READY;reason="all target chunks FULL; safety audit still required";}
                    else loadCursor=0;
                }
            }
        }catch(RuntimeException failure){fail("native acquisition failure: "+failure);}
    }
    private void fail(String why){reason=why;state=State.FAILED;release();}
    private void release(){for(Key key:tickets)key.world.method_14178().method_17300(TICKET,new class_1923(key.x,key.z),0,owner);tickets.clear();scans.clear();loads.clear();}
    @Override public void close(){thread();if(state!=State.FAILED){state=State.CANCELLED;reason="released";}release();}
}
