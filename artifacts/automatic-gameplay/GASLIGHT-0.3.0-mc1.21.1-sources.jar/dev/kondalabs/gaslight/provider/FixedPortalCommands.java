package dev.kondalabs.gaslight.provider;

import com.mojang.brigadier.arguments.DoubleArgumentType;
import com.mojang.brigadier.context.CommandContext;
import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;
import net.minecraft.class_2168;
import net.minecraft.class_2170;
import net.minecraft.class_243;
import net.minecraft.class_2561;

/** Explicit fixed-link operations, still subject to the adapter's observer and world vetoes. */
final class FixedPortalCommands {
    static void register(){
        CommandRegistrationCallback.EVENT.register((dispatcher,access,environment)->dispatcher.register(
            class_2170.method_9247("gaslight-fixed").requires(s->s.method_9259(4))
                .then(class_2170.method_9247("status").executes(c->{var a=GaslightProvider.service(c.getSource().method_9211());c.getSource().method_9226(()->class_2561.method_43470(a.status().toString()),false);return 1;}))
                .then(class_2170.method_9247("retire").executes(c->{var a=GaslightProvider.service(c.getSource().method_9211());boolean ok=a.retire(a.token());c.getSource().method_9226(()->class_2561.method_43470(a.status().toString()),false);return ok?1:0;}))
                .then(coordinates("create",false)).then(coordinates("acquire",true))
                .then(class_2170.method_9247("cancel-acquisition").executes(c->{var a=GaslightProvider.service(c.getSource().method_9211());return a.cancelPreparation(a.preparationOwner())?1:0;}))));
    }
    private static com.mojang.brigadier.builder.LiteralArgumentBuilder<class_2168> coordinates(String name,boolean saved){
        return class_2170.method_9247(name)
            .then(class_2170.method_9244("x",DoubleArgumentType.doubleArg(-29000000,29000000))
            .then(class_2170.method_9244("y",DoubleArgumentType.doubleArg(-2048,2048))
            .then(class_2170.method_9244("z",DoubleArgumentType.doubleArg(-29000000,29000000))
            .then(class_2170.method_9244("tx",DoubleArgumentType.doubleArg(-29000000,29000000))
            .then(class_2170.method_9244("ty",DoubleArgumentType.doubleArg(-2048,2048))
            .then(class_2170.method_9244("tz",DoubleArgumentType.doubleArg(-29000000,29000000)).executes(c->create(c,saved))))))));
    }
    private static int create(CommandContext<class_2168> c,boolean saved){
        var source=c.getSource();var a=GaslightProvider.service(source.method_9211());
        var origin=new class_243(value(c,"x"),value(c,"y"),value(c,"z"));var target=new class_243(value(c,"tx"),value(c,"ty"),value(c,"tz"));
        var spec=new FixedPortalAdapter.Spec(source.method_9225(),origin,source.method_9225(),target,4,4);
        boolean ok=saved?a.acquireSaved(spec):a.prepare(spec);
        source.method_9226(()->class_2561.method_43470(a.status().toString()),false);return ok?1:0;
    }
    private static double value(CommandContext<class_2168> c,String name){return DoubleArgumentType.getDouble(c,name);}
}
