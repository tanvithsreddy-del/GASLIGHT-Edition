package dev.kondalabs.gaslight.provider;
import net.minecraft.class_1299;
import net.minecraft.class_1311;
import net.minecraft.class_1937;
import net.minecraft.class_2378;
import net.minecraft.class_2960;
import net.minecraft.class_7923;
import net.minecraft.world.entity.*;
import qouteall.imm_ptl.core.portal.Portal;

/** GASLIGHT owns the entity type. It is never serialized into world entity files.
 * Removing this mod cannot turn its entities into ordinary provider portals. */
public final class EphemeralPortal extends Portal {
    public static final class_1299<EphemeralPortal> TYPE=class_2378.method_10230(class_7923.field_41177,
        class_2960.method_60655("gaslight_provider","ephemeral_portal"),
        class_1299.class_1300.<EphemeralPortal>method_5903(EphemeralPortal::new,class_1311.field_17715).method_17687(0,0).method_19947().method_5904().method_5901().method_27299(6).method_27300(20).method_5905("gaslight_provider:ephemeral_portal"));
    public EphemeralPortal(class_1299<?> type,class_1937 world){super(type,world);}
    public static void initialize(){}
    @Override public boolean method_31746(){return false;}
}
