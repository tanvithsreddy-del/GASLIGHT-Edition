package dev.kondalabs.gaslight.provider;

import java.util.*;
import dev.kondalabs.gaslight.NativePortal.*;
import dev.kondalabs.gaslight.ProtectedChunkRegions;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_2960;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_5218;
import net.minecraft.class_5321;
import net.minecraft.class_7924;
import net.minecraft.resources.*;
import net.minecraft.server.MinecraftServer;
import net.minecraft.server.level.*;
import qouteall.imm_ptl.core.api.PortalAPI;
import qouteall.imm_ptl.core.chunk_loading.ChunkLoader;
import qouteall.imm_ptl.core.portal.*;

/** Private-world gameplay controller. Native source terrain is read, never erased.
 * A staged scene owns tickets and a durable intent before it can be offered. */
public final class AutomaticPortalService {
    static final class_5321<class_1937> WORLD=class_5321.method_29179(class_7924.field_41223,class_2960.method_60655("gaslight_provider","unobserved"));
    private final MinecraftServer server;
    private class_3222 player;
    private class_3218 world,returnWorld;
    private class_243 returnPosition;
    private UUID session;
    private SqliteIntentStore journal;
    private SceneTraffic traffic;
    private SceneLease entering;
    private Scene staged,current;
    private String state="IDLE",reason="use /gaslight begin to enter a private world";
    private long lastProposal,receivedWindow;
    private int packets;
    private final Set<UUID> permits=new HashSet<>();
    private final SceneWorkBudget workBudget=new SceneWorkBudget(System.nanoTime());
    private int oldRadius,oldLayers,oldRenderLimit;
    static String digest(List<class_2680> blocks){try{var hash=java.security.MessageDigest.getInstance("SHA-256");for(var s:blocks){int n=net.minecraft.class_2248.method_9507(s);hash.update((byte)(n>>>24));hash.update((byte)(n>>>16));hash.update((byte)(n>>>8));hash.update((byte)n);}return HexFormat.of().formatHex(hash.digest());}catch(java.security.NoSuchAlgorithmException e){throw new IllegalStateException(e);}}
    private static final class Scene {
        long generation,start=System.nanoTime(),finishedCopyAt,offeredAt;
        class_243 origin,destination;boolean xPlane;int sign,minY,maxY;
        SceneLease lease;ChunkLoader loader;GenerationFence fence;SceneProtocol.Offer offer;
        final List<Portal> portals=new ArrayList<>();
        final List<class_2338> seam=new ArrayList<>();final List<class_2680> states=new ArrayList<>();
        final List<class_2338> sourceCells=new ArrayList<>();
        int copying;
        boolean clientReady,armed;
    }
    AutomaticPortalService(MinecraftServer server){this.server=server;}
    private void thread(){if(!server.method_18854())throw new IllegalStateException("server thread required");}
    public String status(){return "state="+state+",reason="+reason+",generation="+(current==null?0:current.generation)+",staged="+(staged==null?0:staged.generation)+",origin="+(current==null?null:current.origin)+",destination="+(current==null?null:current.destination)+",portals="+permits.size()+",tickets="+((entering==null?0:entering.tickets())+(staged==null?0:staged.lease.tickets())+(current==null?0:current.lease.tickets()))+",intents="+(journal==null?0:journal.outstanding())+","+(traffic==null?"traffic=inactive":traffic.status());}
    public boolean begin(class_3222 requested){
        thread();if(player!=null||server.method_3760().method_14571().size()!=1||requested.method_5765()||!ServerPlayNetworking.canSend(requested,SceneProtocol.Offer.TYPE)){reason="one compatible unmounted player is required";return false;}
        if(!SceneProtocol.supported(requested)){reason="tested profile requires a GASLIGHT client, vanilla renderer and render distance 2–4";return false;}
        world=server.method_3847(WORLD);if(world==null){reason="private dimension unavailable";return false;}
        journal=new SqliteIntentStore(server.method_27050(class_5218.field_24188).resolve("dimensions/gaslight_provider/unobserved/data/scene-intents.sqlite"),2);
        if(!journal.reconcileWithLoadVeto()){reason=journal.diagnostic();GaslightProvider.LOG.error("GASLIGHT_BEGIN_REFUSED {}",reason);journal.close();journal=null;return false;}
        SqliteIntentStore.Anchor anchor;
        if(requested.method_37908().method_27983().equals(WORLD))anchor=journal.loadAnchor(requested.method_5667());
        else{anchor=new SqliteIntentStore.Anchor(requested.method_37908().method_27983().method_29177().toString(),requested.method_23317(),requested.method_23318(),requested.method_23321());if(!journal.saveAnchor(requested.method_5667(),anchor))anchor=null;}
        if(anchor==null){reason="original return point unavailable: "+journal.diagnostic();journal.close();journal=null;return false;}
        returnWorld=server.method_3847(class_5321.method_29179(class_7924.field_41223,class_2960.method_60654(anchor.dimension())));
        if(returnWorld==null){reason="original return dimension unavailable";journal.close();journal=null;return false;}
        player=requested;returnPosition=new class_243(anchor.x(),anchor.y(),anchor.z());session=UUID.randomUUID();
        oldRadius=qouteall.imm_ptl.core.IPGlobal.indirectLoadingRadiusCap;oldLayers=qouteall.imm_ptl.core.IPGlobal.maxPortalLayer;oldRenderLimit=qouteall.imm_ptl.core.IPGlobal.portalRenderLimit;
        qouteall.imm_ptl.core.IPGlobal.indirectLoadingRadiusCap=3;qouteall.imm_ptl.core.IPGlobal.maxPortalLayer=2;qouteall.imm_ptl.core.IPGlobal.portalRenderLimit=4;
        try{traffic=SceneTraffic.attach(player);entering=new SceneLease(world,512,512,2);state="ENTERING";reason="preparing native private-world arrival";return true;}
        catch(RuntimeException bad){fail(bad.toString());return false;}
    }
    boolean permits(Portal p){return permits.contains(p.method_5667());}
    boolean active(String tag){var id=SceneVisibility.parse(tag);return id!=null&&session!=null&&id.session().equals(session)&&current!=null&&id.generation()==current.generation&&current.fence.state()==GenerationFence.State.COMMITTED;}
    private void audit(class_243 origin,boolean xPlane){
        var policy=ProtectedChunkRegions.load(server.method_27050(class_5218.field_24188).resolve("gaslight-protected-chunks.csv"));
        if(!policy.valid())throw new IllegalStateException(policy.reason());
        var surface=new Surface(new V(origin.field_1352,origin.field_1351,origin.field_1350),xPlane?new V(0,0,1):new V(1,0,0),64,world.method_31605());
        String[] detail={""};
        var verdict=dev.kondalabs.gaslight.StructureEnvelope.audit(surface,1,64,(x,z)->{
            var chunk=world.method_14178().method_21730(x,z);
            if(chunk==null)return dev.kondalabs.gaslight.StructureEnvelope.Result.UNKNOWN;
            if(policy.protectedAt(x,z))return dev.kondalabs.gaslight.StructureEnvelope.Result.USER_PROTECTED;
            if(chunk.method_12016().values().stream().anyMatch(s->s!=null&&s.method_16657())||chunk.method_12179().values().stream().anyMatch(r->!r.isEmpty())){
                var registry=world.method_30349().method_30530(class_7924.field_41246);
                detail[0]=" actual="+chunk.method_12004()+" starts="+chunk.method_12016().entrySet().stream().filter(e->e.getValue().method_16657()).limit(8).map(e->registry.method_10221(e.getKey())+"@"+e.getValue().method_34000()).toList()+" references="+chunk.method_12179().entrySet().stream().filter(e->!e.getValue().isEmpty()).limit(8).map(e->registry.method_10221(e.getKey())+":"+e.getValue().size()).toList();
                return dev.kondalabs.gaslight.StructureEnvelope.Result.STRUCTURE;
            }
            return dev.kondalabs.gaslight.StructureEnvelope.Result.SAFE;
        });
        if(!verdict.accepted())throw new IllegalStateException(verdict.reason()+detail[0]);
    }
    private void propose(){
        if(journal.blockedOnOpen())throw new IllegalStateException(journal.diagnostic());
        Scene s=new Scene();s.generation=journal.nextGeneration();s.minY=world.method_31607();s.maxY=world.method_31600();
        class_243 forward=player.method_5720();s.xPlane=Math.abs(forward.field_1352)>Math.abs(forward.field_1350);s.sign=(s.xPlane?forward.field_1352:forward.field_1350)>=0?1:-1;
        double coord=s.xPlane?player.method_23317():player.method_23321();double plane=s.sign>0?Math.floor(coord)-4:Math.ceil(coord)+4;
        s.origin=new class_243(s.xPlane?plane:Math.floor(player.method_23317())+.5,(s.minY+s.maxY)/2.0,s.xPlane?Math.floor(player.method_23321())+.5:plane);
        try{audit(s.origin,s.xPlane);}catch(IllegalStateException veto){reason="source safety veto: "+veto.getMessage();state=current==null?"WAITING_SAFE_SITE":"ACTIVE";return;}
        Runtime runtime=Runtime.getRuntime();
        if(!workBudget.consume(System.nanoTime(),runtime.totalMemory()-runtime.freeMemory(),runtime.maxMemory())){reason="preparation rate or memory budget exhausted";state=current==null?"WAITING_BUDGET":"ACTIVE";return;}
        // Every reservation occupies a new native site; aborted attempts are retained too.
        int cell=(int)s.generation;if(cell>4000)throw new IllegalStateException("retained history budget; checkpoint required");
        s.destination=new class_243(8192+(cell%64)*256+(s.origin.field_1352-Math.floor(s.origin.field_1352)),s.origin.field_1351,16384+(cell/64)*256+(s.origin.field_1350-Math.floor(s.origin.field_1350)));
        Surface a=new Surface(new V(s.origin.field_1352,s.origin.field_1351,s.origin.field_1350),s.xPlane?new V(0,0,1):new V(1,0,0),64,s.maxY-s.minY);
        Surface b=new Surface(new V(s.destination.field_1352,s.destination.field_1351,s.destination.field_1350),a.tangent(),64,a.height());
        if(!journal.begin(List.of(new Passage(a,b,session,s.generation))))throw new IllegalStateException(journal.diagnostic());
        // A 64-block seam plus a 17-block structure halo can touch cx-4.
        // The three-chunk presentation window alone cannot certify that column.
        s.lease=new SceneLease(world,Math.floorDiv((int)Math.floor(s.destination.field_1352),16),Math.floorDiv((int)Math.floor(s.destination.field_1350),16),4,true);
        s.fence=new GenerationFence(session,s.generation,System.nanoTime()+60_000_000_000L);staged=s;state="PREPARING";reason="native terrain generation and full-height seam preparation";
        GaslightProvider.LOG.info("GASLIGHT_SCENE_PREPARING g={} dependencyFootprint={}",s.generation,s.lease.dependencies);
    }
    private void captureSeam(Scene s){
        audit(s.origin,s.xPlane);audit(s.destination,s.xPlane);
        class_2338 a=class_2338.method_49638(s.origin),b=class_2338.method_49638(s.destination);
        for(int tangent=-32;tangent<32;tangent++)for(int normal=-1;normal<=0;normal++)for(int y=s.minY;y<s.maxY;y++) {
            class_2338 source=new class_2338(a.method_10263()+(s.xPlane?normal:tangent),y,a.method_10260()+(s.xPlane?tangent:normal));
            var block=world.method_8320(source);
            if(block.method_31709())throw new IllegalStateException("block entity intersects seam");
            var target=new class_2338(b.method_10263()+(s.xPlane?normal:tangent),y,b.method_10260()+(s.xPlane?tangent:normal));
            if(world.method_8320(target).method_31709())throw new IllegalStateException("destination block entity intersects seam");
            s.seam.add(target);
            s.states.add(block);
            s.sourceCells.add(source);
        }
        var bounds=new net.minecraft.class_3341(b.method_10263()+(s.xPlane?-1:-32),s.minY,b.method_10260()+(s.xPlane?-32:-1),b.method_10263()+(s.xPlane?0:31),s.maxY-1,b.method_10260()+(s.xPlane?31:0));
        // These positions belong to a new, unpublished private reservation. Old
        // generation ticks must not be applied to their transplanted states.
        world.method_14196().method_39380(bounds);world.method_14179().method_39380(bounds);
    }
    private void offer(Scene s){
        audit(s.origin,s.xPlane);audit(s.destination,s.xPlane);
        if(!seamUnchanged(s))throw new IllegalStateException("source or destination seam changed during preparation");
        Portal p=ScenePortal.TYPE.method_5883(world);if(p==null)throw new IllegalStateException("scene portal creation");
        p.setOriginPos(s.origin);p.setOrientationAndSize(s.xPlane?new class_243(0,0,-s.sign):new class_243(s.sign,0,0),new class_243(0,1,0),64,s.maxY-s.minY);p.setDestinationDimension(WORLD);p.setDestination(s.destination);p.setRotation(null);p.setScaleTransformation(1);
        Portal flipped=PortalManipulation.createFlippedPortal(p,ScenePortal.TYPE),reverse=PortalManipulation.createReversePortal(p,ScenePortal.TYPE),reverseFlipped=PortalManipulation.createFlippedPortal(reverse,ScenePortal.TYPE);
        for(Portal portal:List.of(p,flipped,reverse,reverseFlipped)) {
            portal.portalTag=SceneVisibility.PREFIX+session+":"+s.generation;portal.specificPlayerId=player.method_5667();permits.add(portal.method_5667());s.portals.add(portal);
            if(!world.method_8649(portal))throw new IllegalStateException("scene spawn refused");
        }
        s.offer=new SceneProtocol.Offer(session,s.generation,s.origin,s.destination,s.xPlane,s.sign,s.minY,s.maxY,p.method_5667(),flipped.method_5667(),current==null?null:current.origin,current==null?null:current.destination,current!=null&&current.xPlane,current==null?1:current.sign,digest(s.states));
        s.offeredAt=System.nanoTime();s.fence=new GenerationFence(session,s.generation,s.offeredAt+45_000_000_000L);
        ServerPlayNetworking.send(player,s.offer);state="OFFERED";reason="waiting for real client data, lighting, meshes and an excluded rendered frame";
        GaslightProvider.LOG.info("GASLIGHT_SCENE_OFFERED g={} cells={} {} -> {} digest={} samples={}",s.generation,s.seam.size(),s.origin,s.destination,digest(s.states),List.of(s.states.getFirst(),s.states.get((s.maxY-s.minY)/2),s.states.get(32*2*(s.maxY-s.minY)+(s.maxY-s.minY)/2)));
    }
    void clientReady(class_3222 sender,SceneProtocol.Ready packet){
        thread();
        if(sender!=player||staged==null||staged.offer==null||!packet.session().equals(session)||packet.generation()!=staged.generation)return;
        if(packet.cells()!=staged.states.size()||!packet.seamDigest().equals(staged.offer.seamDigest())||!seamUnchanged(staged)){GaslightProvider.LOG.info("GASLIGHT_READINESS_REFUSED g={} cells={} digestMatch={} difference={}",packet.generation(),packet.cells(),packet.seamDigest().equals(staged.offer.seamDigest()),seamDifference(staged));return;}
        staged.clientReady=true;
        GaslightProvider.LOG.info("GASLIGHT_CLIENT_READINESS_RECEIPT g={} compiledSections={} cells={}",packet.generation(),packet.meshes(),packet.cells());arm(staged);
    }
    private boolean clear(Scene scene){return scene==null||scene.portals.stream().allMatch(p->p.method_37908().method_8333(p,p.method_5829().method_1014(.75),e->!(e instanceof Portal)).isEmpty());}
    private void arm(Scene scene){
        if(scene.armed||!scene.clientReady||!seamUnchanged(scene)||!clear(scene)||!clear(current))return;
        if(scene.fence.ready(session,scene.generation,true,true,true,System.nanoTime())){
            scene.armed=true;ServerPlayNetworking.send(player,new SceneProtocol.Armed(session,scene.generation));GaslightProvider.LOG.info("GASLIGHT_SERVER_ARMED g={}",scene.generation);
        }
    }
    void cancel(class_3222 sender,SceneProtocol.Cancel packet){
        thread();
        if(sender!=player||staged==null||!packet.session().equals(session)||packet.generation()!=staged.generation||staged.fence.state()==GenerationFence.State.SELECTING||staged.fence.state()==GenerationFence.State.COMMITTED)return;
        long generation=staged.generation;staged.fence.fail();release(staged,true);staged=null;
        reason="unselected offer cancelled; active scene preserved";state=current==null?"ACTIVE_EMPTY":"ACTIVE";lastProposal=System.nanoTime();
        ServerPlayNetworking.send(sender,new SceneProtocol.Withdraw(session,generation));GaslightProvider.LOG.info("GASLIGHT_SCENE_CANCELLED g={} {}",generation,status());
    }
    void select(class_3222 sender,SceneProtocol.Selection packet){
        thread();long now=System.nanoTime();if(now-receivedWindow>1_000_000_000L){receivedWindow=now;packets=0;}
        boolean accepted=false;
        if(++packets<=12&&sender==player&&staged!=null&&staged.offer!=null&&sender.method_37908().method_27983().equals(WORLD)&&!sender.method_5765()) {
            Scene s=staged;double distance=sender.method_33571().method_1025(new class_243(packet.clip().x(),packet.clip().y(),packet.clip().z()));
            double side=(s.xPlane?sender.method_23317()-s.origin.field_1352:sender.method_23321()-s.origin.field_1350)*s.sign;
            boolean unoccupied=s.portals.stream().allMatch(p->p.method_37908().method_8333(p,p.method_5829().method_1014(.75),e->!(e instanceof Portal)).isEmpty());
            boolean oldClear=current==null||current.portals.stream().allMatch(p->p.method_37908().method_8333(p,p.method_5829().method_1014(.75),e->!(e instanceof Portal)).isEmpty());
            GaslightProvider.LOG.info("GASLIGHT_SELECTION_GATE g={} eyeDistanceSq={} side={} sourceDistanceSq={} newClear={} oldClear={} seamStable={} hidden={} serverFence={}",s.generation,distance,side,sender.method_19538().method_1025(new class_243(s.origin.field_1352,sender.method_23318(),s.origin.field_1350)),unoccupied,oldClear,seamUnchanged(s),s.offer.hidden(packet.clip()),s.fence.state());
            if(distance<36&&side>1&&sender.method_19538().method_1025(new class_243(s.origin.field_1352,sender.method_23318(),s.origin.field_1350))<256&&unoccupied&&oldClear&&seamUnchanged(s)&&s.offer.hidden(packet.clip())&&s.fence.select(packet.session(),packet.generation(),packet.frame(),true,true,now)) {
                if(current!=null){if(!current.fence.retire(session,current.generation,oldClear,true))throw new IllegalStateException("active retirement fence refused");release(current,true);}
                accepted=s.fence.commit(packet.session(),packet.generation(),packet.frame(),now);
                if(accepted){current=s;staged=null;state="ACTIVE";reason="atomic scene selected";lastProposal=now;GaslightProvider.LOG.info("GASLIGHT_SCENE_COMMITTED g={} frame={} {}",s.generation,packet.frame(),status());}
            }
        }
        ServerPlayNetworking.send(sender,new SceneProtocol.Ack(packet.session(),packet.generation(),packet.frame(),accepted));
        if(!accepted&&sender==player)fail("scene selection rejected; retained recovery intent");
    }
    private boolean seamUnchanged(Scene s){for(int i=0;i<s.states.size();i++)if(world.method_8320(s.sourceCells.get(i))!=s.states.get(i)||world.method_8320(s.seam.get(i))!=s.states.get(i))return false;return true;}
    private String seamDifference(Scene s){for(int i=0;i<s.states.size();i++){var a=world.method_8320(s.sourceCells.get(i));var b=world.method_8320(s.seam.get(i));if(a!=s.states.get(i)||b!=s.states.get(i))return "index="+i+" expected="+s.states.get(i)+" source="+s.sourceCells.get(i)+":"+a+" destination="+s.seam.get(i)+":"+b;}return "stable";}
    private void release(Scene s,boolean settle){
        for(Portal p:s.portals){permits.remove(p.method_5667());p.setTeleportable(false);p.method_31472();}s.portals.clear();
        if(s.loader!=null&&player!=null)PortalAPI.removeChunkLoaderForPlayer(player,s.loader);
        if(s.lease!=null)s.lease.close();
        if(settle&&!journal.settle(session,s.generation))throw new IllegalStateException("durable retirement failed: "+journal.diagnostic());
    }
    void tick(){
        thread();if(player==null||state.equals("FAILED"))return;
        if(player.method_31481()||server.method_3760().method_14571().size()!=1){disconnected(player);return;}
        try {
            if(entering!=null&&entering.tick()) {
                int y=world.method_8624(class_2902.class_2903.field_13203,8192,8192);
                if(!world.method_8316(new class_2338(8192,y-1,8192)).method_15769())throw new IllegalStateException("unsafe private arrival");
                PortalAPI.teleportEntity(player,world,new class_243(8192.5,y+1,8192.5));entering.close();entering=null;state="ACTIVE_EMPTY";lastProposal=System.nanoTime()+3_000_000_000L;
            }
            if(entering!=null)return;
            if(!player.method_37908().method_27983().equals(WORLD)){disconnected(player);return;}
            if(staged!=null&&staged.offer==null&&player.method_19538().method_1025(new class_243(staged.origin.field_1352,player.method_23318(),staged.origin.field_1350))>=256){
                reason="source moved during preparation; unpublished reservation retired";GaslightProvider.LOG.info("GASLIGHT_CANDIDATE_VETO g={} {}",staged.generation,reason);release(staged,true);staged=null;state=current==null?"ACTIVE_EMPTY":"ACTIVE";return;
            }
            if(staged!=null&&player.method_19538().method_1025(new class_243(staged.destination.field_1352,player.method_23318(),staged.destination.field_1350))<128*128)throw new IllegalStateException("player observed or approached the unpublished private reservation");
            if(staged==null&&System.nanoTime()-lastProposal>1_000_000_000L){lastProposal=System.nanoTime();
                int cx=Math.floorDiv((int)Math.floor(player.method_23317()),16),cz=Math.floorDiv((int)Math.floor(player.method_23321()),16);boolean loaded=true;
                for(int x=cx-3;x<=cx+3;x++)for(int z=cz-3;z<=cz+3;z++)loaded&=world.method_14178().method_21730(x,z)!=null;
                if(loaded)propose();else reason="waiting for native source footprint";
            }
            if(staged!=null&&staged.offer==null&&staged.lease.tick()) {
                if(staged.loader==null){staged.loader=new ChunkLoader(WORLD,Math.floorDiv((int)Math.floor(staged.destination.field_1352),16),Math.floorDiv((int)Math.floor(staged.destination.field_1350),16),3);PortalAPI.addChunkLoaderForPlayer(player,staged.loader);return;}
                // FULL chunks alone do not run queued block physics. Prepare
                // genuine ticking chunks before copying, not after the offer.
                int dx=Math.floorDiv((int)Math.floor(staged.destination.field_1352),16),dz=Math.floorDiv((int)Math.floor(staged.destination.field_1350),16);
                for(int x=dx-3;x<=dx+3;x++)for(int z=dz-3;z<=dz+3;z++){
                    var holder=((qouteall.imm_ptl.core.ducks.IEChunkMap)world.method_14178().field_17254).ip_getChunkHolder(net.minecraft.class_1923.method_8331(x,z));
                    if(holder==null||holder.method_16144()==null)return;
                }
                if(staged.states.isEmpty()){
                    try{captureSeam(staged);}catch(IllegalStateException veto){reason="candidate safety veto: "+veto.getMessage();GaslightProvider.LOG.info("GASLIGHT_CANDIDATE_VETO g={} {}",staged.generation,reason);release(staged,true);staged=null;state=current==null?"WAITING_SAFE_SITE":"ACTIVE";return;}
                }
                int end=Math.min(staged.copying+2048,staged.seam.size());
                if(player.method_19538().method_1025(new class_243(staged.destination.field_1352,player.method_23318(),staged.destination.field_1350))<128*128)throw new IllegalStateException("player approached private reservation during copying");
                for(;staged.copying<end;staged.copying++)SceneTerrainCopy.block(world,staged.seam.get(staged.copying),staged.states.get(staged.copying));
                if(staged.copying==staged.seam.size()){
                    if(staged.finishedCopyAt==0)staged.finishedCopyAt=System.nanoTime();
                    if(System.nanoTime()-staged.finishedCopyAt>2_000_000_000L&&!world.method_14178().method_17293().method_15518()){
                        if(!seamUnchanged(staged)){reason="native block physics changed the copied seam; candidate retired";GaslightProvider.LOG.info("GASLIGHT_CANDIDATE_VETO g={} {}",staged.generation,reason);release(staged,true);staged=null;state=current==null?"WAITING_SAFE_SITE":"ACTIVE";return;}
                        offer(staged);
                    }
                }
            }
            if(staged!=null&&staged.offer!=null)arm(staged);
            if(staged!=null&&(staged.offeredAt==0?System.nanoTime()-staged.start>60_000_000_000L:System.nanoTime()-staged.offeredAt>44_000_000_000L))throw new IllegalStateException("scene preparation/selection timeout");
        }catch(RuntimeException failure){fail(failure.toString());}
    }
    private void fail(String why){reason=why;GaslightProvider.LOG.error("GASLIGHT_GAMEPLAY_FAILED {}",why);state="FAILED";if(entering!=null){entering.close();entering=null;}boolean offered=staged!=null&&staged.offer!=null;if(staged!=null){release(staged,false);staged=null;}if(offered&&player!=null)player.field_13987.method_52396(net.minecraft.class_2561.method_43470("GASLIGHT retained a failed publication intent: "+why));}
    void disconnected(class_3222 who){if(who!=player)return;shutdown();}
    public void leave(){thread();if(player!=null&&returnWorld!=null&&returnPosition!=null)PortalAPI.teleportEntity(player,returnWorld,returnPosition);shutdown();}
    void shutdown(){thread();if(entering!=null){entering.close();entering=null;}if(staged!=null){release(staged,false);staged=null;}if(current!=null){release(current,false);current=null;}permits.clear();if(traffic!=null){traffic.close();traffic=null;}if(player!=null){qouteall.imm_ptl.core.IPGlobal.indirectLoadingRadiusCap=oldRadius;qouteall.imm_ptl.core.IPGlobal.maxPortalLayer=oldLayers;qouteall.imm_ptl.core.IPGlobal.portalRenderLimit=oldRenderLimit;}player=null;session=null;if(journal!=null){journal.close();journal=null;}state="IDLE";}
}
