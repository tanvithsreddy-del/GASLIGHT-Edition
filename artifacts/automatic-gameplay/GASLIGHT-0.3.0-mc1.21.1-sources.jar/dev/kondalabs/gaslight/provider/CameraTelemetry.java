package dev.kondalabs.gaslight.provider;
import java.util.*;
import net.fabricmc.fabric.api.networking.v1.*;
import net.minecraft.class_2960;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import net.fabricmc.fabric.api.event.lifecycle.v1.ServerTickEvents;

/** Connection-authenticated, session/generation/dimension-fenced camera telemetry.
 * ADVISORY ONLY: receiving a prior frame never authorizes physical publication. */
public final class CameraTelemetry {
    public record Challenge(UUID session,long generation) implements class_8710 {
        public static final class_9154<Challenge> TYPE=new class_9154<>(class_2960.method_60655("gaslight_provider","camera_challenge"));
        public static final class_9139<class_9129,Challenge> CODEC=class_9139.method_56437((b,p)->{b.method_10797(p.session);b.method_52974(p.generation);},b->new Challenge(b.method_10790(),b.readLong()));
        public class_9154<Challenge> method_56479(){return TYPE;}
    }
    public record Observation(UUID session,long generation,long frame,String dimension,FrameClip clip,boolean supported) implements class_8710 {
        public static final class_9154<Observation> TYPE=new class_9154<>(class_2960.method_60655("gaslight_provider","camera_observation"));
        public static final class_9139<class_9129,Observation> CODEC=class_9139.method_56437((b,p)->{
            b.method_10797(p.session);b.method_52974(p.generation);b.method_52974(p.frame);b.method_10788(p.dimension,128);b.method_52940(p.clip.x());b.method_52940(p.clip.y());b.method_52940(p.clip.z());for(float f:p.clip.matrix())b.method_52941(f);b.method_52964(p.supported);
        },b->{UUID s=b.method_10790();long g=b.readLong(),f=b.readLong();String d=b.method_10800(128);double x=b.readDouble(),y=b.readDouble(),z=b.readDouble();float[] m=new float[16];for(int i=0;i<16;i++)m[i]=b.readFloat();return new Observation(s,g,f,d,new FrameClip(x,y,z,m),b.readBoolean());});
        public class_9154<Observation> method_56479(){return TYPE;}
    }
    static final class Session {
        final UUID nonce=UUID.randomUUID();final long generation;final String dimension;
        long sequence=-1,lastReceived,window;int packets,accepted,rejected;Observation latest;
        Session(long generation,String dimension){this.generation=generation;this.dimension=dimension;}
        boolean accept(Observation p,double playerX,double playerY,double playerZ,long now){
            if(now-window>1_000_000_000L){window=now;packets=0;}
            double distance=Math.pow(p.clip.x()-playerX,2)+Math.pow(p.clip.y()-playerY,2)+Math.pow(p.clip.z()-playerZ,2);
            if(++packets>12||!nonce.equals(p.session)||generation!=p.generation||!dimension.equals(p.dimension)||p.frame<=sequence||!p.supported||distance>100){rejected++;latest=null;return false;}
            sequence=p.frame;lastReceived=now;latest=p;accepted++;return true;
        }
        String status(long now){return "frame="+sequence+",accepted="+accepted+",rejected="+rejected+",fresh="+(latest!=null&&now-lastReceived<300_000_000L)+",advisoryOnly=true";}
    }
    private static final Map<net.minecraft.server.MinecraftServer,Map<UUID,Session>> servers=new IdentityHashMap<>();
    private static Map<UUID,Session> sessions(net.minecraft.server.MinecraftServer server){return servers.computeIfAbsent(server,ignored->new HashMap<>());}
    public static String status(net.minecraft.server.MinecraftServer server,UUID player){Session s=sessions(server).get(player);return s==null?"no camera session":s.status(System.nanoTime());}
    static void initialize(){
        PayloadTypeRegistry.playS2C().register(Challenge.TYPE,Challenge.CODEC);PayloadTypeRegistry.playC2S().register(Observation.TYPE,Observation.CODEC);
        ServerPlayConnectionEvents.DISCONNECT.register((handler,server)->sessions(server).remove(handler.field_14140.method_5667()));
        ServerTickEvents.END_SERVER_TICK.register(server->{
            for(var player:server.method_3760().method_14571()){
                var service=GaslightProvider.service(server);if(service==null)continue;
                long generation=service.status().generation();String dimension=player.method_37908().method_27983().method_29177().toString();
                Session s=sessions(server).get(player.method_5667());
                if((s==null||s.generation!=generation||!s.dimension.equals(dimension))&&ServerPlayNetworking.canSend(player,Challenge.TYPE)){
                    s=new Session(generation,dimension);sessions(server).put(player.method_5667(),s);ServerPlayNetworking.send(player,new Challenge(s.nonce,generation));
                }
            }
        });
        ServerPlayNetworking.registerGlobalReceiver(Observation.TYPE,(packet,context)->{
            var player=context.player();Session s=sessions(context.server()).get(player.method_5667());if(s!=null&&s.accept(packet,player.method_23317(),player.method_23320(),player.method_23321(),System.nanoTime())&&s.accepted==1)GaslightProvider.LOG.info("GASLIGHT_CAMERA_RECEIVED {} {}",player.method_5667(),s.status(System.nanoTime()));
        });
        net.fabricmc.fabric.api.event.lifecycle.v1.ServerLifecycleEvents.SERVER_STOPPED.register(servers::remove);
    }
}
