package dev.kondalabs.gaslight.provider;

import java.util.*;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.networking.v1.*;
import net.fabricmc.fabric.api.client.rendering.v1.WorldRenderEvents;
import net.minecraft.class_2338;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2680;
import net.minecraft.class_2806;
import net.minecraft.class_310;
import net.minecraft.class_419;
import net.minecraft.class_442;
import net.minecraft.class_6850;
import net.minecraft.class_846;
import net.minecraft.client.renderer.chunk.*;
import org.joml.Matrix4f;
import qouteall.imm_ptl.core.ducks.IEWorldRenderer;
import qouteall.imm_ptl.core.render.ImmPtlViewArea;
import qouteall.imm_ptl.core.render.context_management.PortalRendering;

/** Owns the frame barrier; the server never guesses a camera from player yaw. */
public final class AutomaticClient implements ClientModInitializer {
    private static SceneProtocol.Offer offer;
    private static GenerationFence fence;
    private static FrameClip camera;
    private static long frame,received,selectedAt;
    private static boolean hidden,main;
    private static int views;
    private static class_243 heldPosition;
    private static final Map<class_846.class_851,class_846.class_849> waiting=new IdentityHashMap<>();
    private static final Set<class_846.class_851> complete=Collections.newSetFromMap(new IdentityHashMap<>());
    private static final List<class_2680> boundary=new ArrayList<>();
    private static int hashCursor;
    private static boolean dataReady,hashReady;
    private static String pendingFailure;
    private static int digestRetries;
    private static long cancellingAt,progressAt;
    private static String readiness="idle";
    private static boolean serverArmed;
    private static boolean supportedProfile(){var mc=class_310.method_1551();var loader=net.fabricmc.loader.api.FabricLoader.getInstance();return !loader.isModLoaded("sodium")&&!loader.isModLoaded("iris")&&mc.field_1690.method_42503().method_41753()<=4;}
    private static boolean playerClearOfPrevious(class_310 mc){
        if(offer.previous()==null)return true;
        var body=mc.field_1724.method_5829().method_1014(.75);
        for(class_243 p:java.util.List.of(offer.previous(),offer.previousDestination())){
            boolean x=offer.previousXPlane();
            if(body.method_994(new net.minecraft.class_238(p.field_1352-(x?.1:32),offer.minY(),p.field_1350-(x?32:.1),p.field_1352+(x?.1:32),offer.maxY(),p.field_1350+(x?32:.1))))return false;
        }
        return true;
    }
    public static boolean selecting(){return pendingFailure!=null||fence!=null&&fence.state()==GenerationFence.State.SELECTING;}
    public static String status(){return "offer="+(offer==null?0:offer.generation())+",fence="+(fence==null?"none":fence.state())+",readiness="+readiness+",meshes="+complete.size()+",pending="+waiting.size()+",boundary="+hashCursor+",frame="+frame+",views="+views+",hidden="+hidden+",selected="+SceneVisibility.selected+",ack="+SceneVisibility.acknowledged;}
    private static void clear(){offer=null;fence=null;camera=null;waiting.clear();complete.clear();boundary.clear();hashCursor=0;dataReady=false;hashReady=false;digestRetries=0;pendingFailure=null;cancellingAt=0;readiness="idle";serverArmed=false;SceneVisibility.clear();}
    private static void fail(String why){
        if(pendingFailure!=null)return;
        GaslightProvider.LOG.error("GASLIGHT_CLIENT_FAILED {}",why);pendingFailure=why;
        if(fence!=null)fence.fail();
        // Minecraft still accesses gameMode after WorldRenderEvents.END. Retain
        // the selected view and close on the next tick, never roll it back here.
        class_310.method_1551().method_1507(new class_419(new class_442(),class_2561.method_43470("GASLIGHT closed the scene"),class_2561.method_43470(why)));
    }
    @Override public void onInitializeClient(){
        net.fabricmc.fabric.api.client.rendering.v1.EntityRendererRegistry.register(ScenePortal.TYPE,qouteall.imm_ptl.core.render.PortalEntityRenderer::new);
        ClientPlayConnectionEvents.DISCONNECT.register((h,c)->clear());
        ClientPlayConnectionEvents.JOIN.register((h,s,c)->{if(ClientPlayNetworking.canSend(SceneProtocol.Caps.TYPE))ClientPlayNetworking.send(new SceneProtocol.Caps(1,supportedProfile(),c.field_1690.method_42503().method_41753()));});
        ClientPlayNetworking.registerGlobalReceiver(SceneProtocol.Offer.TYPE,(p,c)->{
            if(offer!=null||selecting()){fail("overlapping scene offers");return;}
            offer=p;received=System.nanoTime();fence=new GenerationFence(p.session(),p.generation(),received+45_000_000_000L);waiting.clear();complete.clear();boundary.clear();hashCursor=0;hashReady=false;dataReady=false;
            cancellingAt=0;progressAt=received;readiness="waiting for native chunks";serverArmed=false;
            GaslightProvider.LOG.info("GASLIGHT_CLIENT_OFFER {}",p.generation());
        });
        ClientPlayNetworking.registerGlobalReceiver(SceneProtocol.Armed.TYPE,(p,c)->{if(offer!=null&&p.session().equals(offer.session())&&p.generation()==offer.generation()&&cancellingAt==0){serverArmed=true;GaslightProvider.LOG.info("GASLIGHT_CLIENT_ARMED g={}",p.generation());}});
        ClientPlayNetworking.registerGlobalReceiver(SceneProtocol.Withdraw.TYPE,(p,c)->{
            if(offer==null||!p.session().equals(offer.session())||p.generation()!=offer.generation())return;
            if(fence.state()==GenerationFence.State.SELECTING){fail("server withdrew a locally selected generation");return;}
            offer=null;fence=null;waiting.clear();complete.clear();boundary.clear();cancellingAt=0;readiness="cancelled without changing active view";
            GaslightProvider.LOG.info("GASLIGHT_CLIENT_WITHDRAWN g={} {}",p.generation(),status());
        });
        ClientPlayNetworking.registerGlobalReceiver(SceneProtocol.Ack.TYPE,(p,c)->{
            if(fence==null||offer==null||!p.session().equals(offer.session())||p.generation()!=offer.generation())return;
            if(!p.accepted()||!fence.commit(p.session(),p.generation(),p.frame(),System.nanoTime())){fail("server rejected or expired the selected generation");return;}
            SceneVisibility.acknowledged=true;GaslightProvider.LOG.info("GASLIGHT_CLIENT_COMMITTED g={} frame={} ackMs={}",p.generation(),p.frame(),(System.nanoTime()-selectedAt)/1e6);
            offer=null;fence=null;waiting.clear();complete.clear();boundary.clear();
        });
        ClientTickEvents.START_CLIENT_TICK.register(mc->{
            if(pendingFailure!=null){String why=pendingFailure;if(mc.field_1687!=null){mc.field_1687.method_8525();mc.method_18099();}clear();mc.method_1507(new class_419(new class_442(),class_2561.method_43470("GASLIGHT closed the scene"),class_2561.method_43470(why)));return;}
            if(selecting()&&mc.field_1724!=null){mc.field_1724.method_18799(class_243.field_1353);if(heldPosition!=null)mc.field_1724.method_33574(heldPosition);}
        });
        ClientTickEvents.END_CLIENT_TICK.register(mc->{
            if(mc.field_1687==null||!mc.field_1687.method_27983().equals(AutomaticPortalService.WORLD)){if(selecting())fail("dimension changed during scene acknowledgement");else clear();return;}
            if((offer!=null||SceneVisibility.selected!=null)&&!supportedProfile()){fail("this gameplay profile requires the vanilla renderer and render distance 2–4");return;}
            if(offer==null)return;
            long now=System.nanoTime();
            if(selecting()&&now-selectedAt>2_000_000_000L||cancellingAt!=0&&now-cancellingAt>2_000_000_000L){fail("scene acknowledgement timed out");return;}
            boolean moved=mc.field_1724!=null&&mc.field_1724.method_19538().method_1025(new class_243(offer.origin().field_1352,mc.field_1724.method_23318(),offer.origin().field_1350))>=256;
            if((now-received>40_000_000_000L||moved)&&cancellingAt==0&&!selecting()){
                cancellingAt=now;fence.fail();ClientPlayNetworking.send(new SceneProtocol.Cancel(offer.session(),offer.generation()));
                GaslightProvider.LOG.info("GASLIGHT_CLIENT_CANCEL_UNSELECTED {}",status());return;
            }
            if(now-progressAt>2_000_000_000L){progressAt=now;GaslightProvider.LOG.info("GASLIGHT_CLIENT_PROGRESS {}",status());}
        });
        WorldRenderEvents.START.register(c->{if(!PortalRendering.isRendering()){frame++;hidden=true;views=0;camera=null;main=true;}});
        WorldRenderEvents.AFTER_SETUP.register(c->{if(offer==null||!c.world().method_27983().equals(AutomaticPortalService.WORLD))return;
            try{class_243 p=c.camera().method_19326();float[] matrix=new float[16];new Matrix4f(c.projectionMatrix()).mul(c.positionMatrix()).get(matrix);var clip=new FrameClip(p.field_1352,p.field_1351,p.field_1350,matrix);views++;hidden&=offer.hidden(clip);if(!PortalRendering.isRendering())camera=clip;}
            catch(RuntimeException bad){hidden=false;camera=null;}
        });
        WorldRenderEvents.END.register(c->{if(PortalRendering.isRendering()||offer==null||!main)return;main=false;
            try{warm(class_310.method_1551());
                if(serverArmed&&fence.state()==GenerationFence.State.READY&&camera!=null&&views>0&&hidden&&c.world().method_27983().equals(AutomaticPortalService.WORLD)&&c.camera().method_19331()==class_310.method_1551().field_1724&&playerClearOfPrevious(class_310.method_1551())&&fence.select(offer.session(),offer.generation(),frame,true,true,System.nanoTime())){
                    heldPosition=class_310.method_1551().field_1724.method_19538();selectedAt=System.nanoTime();SceneVisibility.acknowledged=false;SceneVisibility.selected=new SceneVisibility.Identity(offer.session(),offer.generation());
                    ClientPlayNetworking.send(new SceneProtocol.Selection(offer.session(),offer.generation(),frame,camera));
                    GaslightProvider.LOG.info("GASLIGHT_CLIENT_SELECTED g={} frame={} views={}",offer.generation(),frame,views);
                }
            }catch(RuntimeException bad){fail("native scene preparation: "+bad);}
        });
    }
    private static void warm(class_310 mc){
        if(fence==null||mc.field_1687==null||fence.state()!=GenerationFence.State.PREPARING&&fence.state()!=GenerationFence.State.READY)return;
        int cx=Math.floorDiv((int)Math.floor(offer.destination().field_1352),16),cz=Math.floorDiv((int)Math.floor(offer.destination().field_1350),16);
        for(int x=cx-3;x<=cx+3;x++)for(int z=cz-3;z<=cz+3;z++)if(mc.field_1687.method_2935().method_2857(x,z,class_2806.field_12803,false)==null){readiness="missing chunk "+x+","+z;fence.invalidateReady(offer.session(),offer.generation(),System.nanoTime());return;}
        boolean first=false,second=false;
        for(var entity:mc.field_1687.method_18112()){first|=entity.method_5667().equals(offer.first());second|=entity.method_5667().equals(offer.second());}
        if(!first||!second||mc.field_1687.method_22336().method_15518()){readiness="portals="+first+","+second+" lightWork="+mc.field_1687.method_22336().method_15518();fence.invalidateReady(offer.session(),offer.generation(),System.nanoTime());return;}
        dataReady=true;
        if(!hashReady){
            class_2338 dest=class_2338.method_49638(offer.destination());int height=offer.maxY()-offer.minY(),count=64*2*height,end=Math.min(hashCursor+4096,count);
            for(;hashCursor<end;hashCursor++){
                int tangent=hashCursor/(2*height)-32,normal=(hashCursor/height)%2-1,y=offer.minY()+hashCursor%height;
                boundary.add(mc.field_1687.method_8320(new class_2338(dest.method_10263()+(offer.xPlane()?normal:tangent),y,dest.method_10260()+(offer.xPlane()?tangent:normal))));
            }
            if(hashCursor<count)return;
            String actual=AutomaticPortalService.digest(boundary);
            if(!actual.equals(offer.seamDigest())){
                if(++digestRetries==1||digestRetries%32==0){
                    var source=new ArrayList<class_2680>();class_2338 origin=class_2338.method_49638(offer.origin());String firstDifference="none";
                    for(int i=0;i<count;i++){
                        int tangent=i/(2*height)-32,normal=(i/height)%2-1,y=offer.minY()+i%height;
                        class_2338 pos=new class_2338(origin.method_10263()+(offer.xPlane()?normal:tangent),y,origin.method_10260()+(offer.xPlane()?tangent:normal));var state=mc.field_1687.method_8320(pos);source.add(state);
                        if(firstDifference.equals("none")&&state!=boundary.get(i))firstDifference="index="+i+" source="+pos+" "+state+" destination="+boundary.get(i);
                    }
                    GaslightProvider.LOG.info("GASLIGHT_SEAM_WAIT g={} retry={} expected={} actual={} nativeSource={} difference={}",offer.generation(),digestRetries,offer.seamDigest(),actual,AutomaticPortalService.digest(source),firstDifference);
                }
                boundary.clear();hashCursor=0;return;
            }
            hashReady=true;boundary.clear();
        }
        var area=((IEWorldRenderer)mc.field_1769).ip_getBuiltChunkStorage();if(!(area instanceof ImmPtlViewArea storage))throw new IllegalStateException("provider view-area contract unavailable");
        var dispatcher=mc.field_1769.method_34810();dispatcher.method_22761();
        for(var it=waiting.entrySet().iterator();it.hasNext();){var e=it.next();var section=e.getKey();if(section.method_3677()!=e.getValue()&&section.method_3677()!=class_846.class_849.field_4451&&!section.method_3672()){complete.add(section);it.remove();}}
        int issued=0,needed=0;var cache=new class_6850();var required=Collections.newSetFromMap(new IdentityHashMap<class_846.class_851,Boolean>());
        for(int x=cx-2;x<=cx+2;x++)for(int z=cz-2;z<=cz+2;z++){
            var chunk=mc.field_1687.method_2935().method_2857(x,z,class_2806.field_12803,false);if(chunk==null)return;
            for(int index=0;index<chunk.method_12006().length;index++){
                if(chunk.method_12006()[index].method_38292())continue;
                int sy=chunk.method_31604(index);var section=storage.provideBuiltChunkByChunkPos(x,sy,z);needed++;
                if(!section.method_3670().equals(new class_2338(x*16,sy*16,z*16)))throw new IllegalStateException("native section coordinate mismatch");
                required.add(section);
                if(section.method_3672())complete.remove(section);
                if(!complete.contains(section)&&!waiting.containsKey(section)&&issued<2&&waiting.size()<16){
                    if(section.method_3677()==class_846.class_849.field_52172){
                        // EMPTY is a shared object; an identity-change fence can
                        // never observe a second successful empty compilation.
                        // Run the real native compiler synchronously for this
                        // case, within the same two-section per-frame budget.
                        section.method_22781(cache);section.method_3662();
                        if(section.method_3677()!=class_846.class_849.field_4451)complete.add(section);
                    }else{waiting.put(section,section.method_3677());section.method_22777(dispatcher,cache);section.method_3662();}
                    issued++;
                }
            }
        }
        // View-area cache objects can be replaced during same-dimension travel.
        // Obsolete objects are neither readiness evidence nor retained ownership.
        complete.retainAll(required);waiting.keySet().retainAll(required);
        readiness="native meshes "+complete.size()+"/"+needed;
        if(needed!=complete.size()||!waiting.isEmpty()||mc.field_1687.method_22336().method_15518())fence.invalidateReady(offer.session(),offer.generation(),System.nanoTime());
        if(needed==complete.size()&&waiting.isEmpty()&&!mc.field_1687.method_22336().method_15518()&&fence.ready(offer.session(),offer.generation(),dataReady,hashReady,true,System.nanoTime())){
            ClientPlayNetworking.send(new SceneProtocol.Ready(offer.session(),offer.generation(),needed,64*2*(offer.maxY()-offer.minY()),offer.seamDigest()));
            long drawSections=complete.stream().filter(section->net.minecraft.class_1921.method_22720().stream().anyMatch(layer->!section.method_3677().method_3641(layer))).count();
            GaslightProvider.LOG.info("GASLIGHT_CLIENT_READY g={} compiledSections={} geometrySections={} elapsedMs={}",offer.generation(),needed,drawSections,(System.nanoTime()-received)/1e6);
        }
    }
}
