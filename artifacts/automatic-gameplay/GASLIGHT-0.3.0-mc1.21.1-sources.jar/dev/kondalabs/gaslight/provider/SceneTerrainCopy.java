package dev.kondalabs.gaslight.provider;

import net.minecraft.class_2338;
import net.minecraft.class_2680;
import net.minecraft.class_2902;
import net.minecraft.class_3218;
import net.minecraft.class_4076;
import net.minecraft.core.*;

/** Copy a surveyed block state into unused, owned private terrain. Raw section
 * copying preserves a naturally suspended block; ordinary placement would start
 * new gravity/plant callbacks. Native heightmaps, light and network dirtying still
 * run. Player actions subsequently use ordinary Minecraft block operations. */
final class SceneTerrainCopy {
    static void block(class_3218 world,class_2338 pos,class_2680 state){
        if(!world.method_27983().equals(AutomaticPortalService.WORLD)||!world.method_8503().method_18854())throw new IllegalStateException("private server terrain only");
        var chunk=world.method_14178().method_21730(pos.method_10263()>>4,pos.method_10260()>>4);
        if(chunk==null||state.method_31709()||chunk.method_8320(pos).method_31709())throw new IllegalStateException("copy preflight failed");
        var section=chunk.method_38259(chunk.method_31602(pos.method_10264()));boolean wasAir=section.method_38292();
        class_2680 old=section.method_16675(pos.method_10263()&15,pos.method_10264()&15,pos.method_10260()&15,state);
        if(old==state)return;
        for(var type:new class_2902.class_2903[]{class_2902.class_2903.field_13197,class_2902.class_2903.field_13203,class_2902.class_2903.field_13200,class_2902.class_2903.field_13202})chunk.method_12032(type).method_12597(pos.method_10263()&15,pos.method_10264(),pos.method_10260()&15,state);
        chunk.method_12008(true);
        var light=world.method_14178().method_17293();
        if(wasAir!=section.method_38292())light.method_15551(class_4076.method_18682(pos),section.method_38292());
        light.method_15513(pos);world.method_14178().method_14128(pos);
    }
}
